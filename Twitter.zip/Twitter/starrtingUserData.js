// her er startverdien for localStorage.userData
let startingUserData = [
    {
        "username": "elonmusk",
        "displayname": "Elon Musk",
        "password": "123",
        "followers": [],
        "following": [],
        "bio": "",
        "quacks": [
            {
                "id": "elonmusk1",
                "likes": [],
                "comments": [],
                "quack": "I propose the LMFAO test for AI",
                "isComment": false
            },
            {
                "id": "elonmusk2",
                "likes": [],
                "comments": [],
                "quack": "The data with which the Federal Reserve is making decisions has too much latency",
                "isComment": false
            },
            {
                "id": "elonmusk3",
                "likes": [],
                "comments": [],
                "quack": "We live in the most interesting of times",
                "isComment": false
            },
            {
                "id": "elonmusk4",
                "likes": [],
                "comments": [],
                "quack": "It’s a fact. Let that sink in.",
                "isComment": true
            },
            {
                "id": "elonmusk5",
                "likes": [],
                "comments": [],
                "quack": "May the 4th be with you ❤️",
                "isComment": false
            },
            {
                "id": "elonmusk6",
                "likes": [],
                "comments": [],
                "quack": "Cult / Culture",
                "isComment": false
            }
        ],
        "like": [],
        "banner": "#80abc6",
        "profilePicture": "ElonMusk.png"
    },
    {
        "username": "Macaiyla",
        "displayname": "Macaiyla",
        "password": "123",
        "followers": [],
        "following": [],
        "bio": "i do not care. shit poster. tyler1’s maid. who asked tho?",
        "quacks": [
            {
                "id": "Macaiyla1",
                "likes": [],
                "comments": [],
                "quack": "My green juice mix just came in the mail yall I’m about to start drinking this shit since I hate veggies. U think my kitty gonna be good for my man now? It’s like takin your dirty dodge ram to the car wash after a year of muddin",
                "isComment": false
            },
            {
                "id": "Macaiyla2",
                "likes": [],
                "comments": [],
                "quack": "Adhd is me putting on my shoes and walking out of the house with mouth wash still in my mouth",
                "isComment": false
            },
            {
                "id": "Macaiyla3",
                "likes": [],
                "comments": [],
                "quack": "I support y’all writers striking but please…I think I speak for all marvel fans when I say the writers of Love and Thunder should be unemployed and broke forever",
                "isComment": false
            }
        ],
        "like": [],
        "banner": "#483b2e",
        "profilePicture": "Macaiyla.png"
    },
    {
        "username": "stats_feed",
        "displayname": "World Of Statistics",
        "password": "123",
        "followers": [],
        "following": [],
        "bio": "There are three kinds of lies: lies, damned lies, and statistics.",
        "quacks": [
            {
                "id": "stats_feed1",
                "likes": [],
                "comments": [],
                "quack": "Only 8% of people manage to keep their New Year’s resolutions.",
                "isComment": false
            },
            {
                "id": "stats_feed2",
                "likes": [],
                "comments": [],
                "quack": "It's estimated that 1 in 8 Americans in the workforce have worked at McDonald's at some point.",
                "isComment": false
            },
            {
                "id": "stats_feed3",
                "likes": [],
                "comments": [],
                "quack": "More than 10% of the world’s salt is used to de-ice American roads.",
                "isComment": false
            },
            {
                "id": "stats_feed4",
                "likes": [],
                "comments": [],
                "quack": "Number of rocket launches since the start of the space age in 1957:  ~ 6380 🚀",
                "isComment": false
            },
            {
                "id": "stats_feed5",
                "likes": [],
                "comments": [],
                "quack": "The average public swimming pool contains 75 litres of urine.",
                "isComment": false
            },
            {
                "id": "stats_feed6",
                "likes": [],
                "comments": [],
                "quack": "The human eye blinks an average of 4,200,000 times a year.",
                "isComment": false
            }
        ],
        "like": [],
        "banner": "#ffffff",
        "profilePicture": "WorldOfStatistics.png"
    },
    {
        "username": "jordanbpeterson",
        "displayname": "Dr Jordan",
        "password": "123",
        "followers": [],
        "following": [],
        "bio": "Best-Selling Author | Clinical Psychologist | #1 Education Podcast |",
        "quacks": [
            {
                "id": "jordanbpeterson1",
                "likes": [],
                "comments": [],
                "quack": "Ford should open a bank",
                "isComment": false
            },
            {
                "id": "jordanbpeterson2",
                "likes": [],
                "comments": [],
                "quack": "I asked ChatGPT about anxiety self-management and it said that because it didn't have a body it wasn't necessary",
                "isComment": false
            },
            {
                "id": "jordanbpeterson3",
                "likes": [],
                "comments": [],
                "quack": "No cars for you peasants. Stay at home and crunch your juicy bugs.",
                "isComment": false
            }
        ],
        "like": [],
        "banner": "#6e726e",
        "profilePicture": "JordanPeterson.png"
    },
    {
        "username": "cb_doge",
        "displayname": "DogeDesigner",
        "password": "123",
        "followers": [],
        "following": [],
        "bio": "UX/UI & Graphic Designer at Dogecoin & MyDoge Inc.",
        "quacks": [
            {
                "id": "cb_doge1",
                "likes": [],
                "comments": [
                    "elonmusk4"
                ],
                "quack": "Fun fact- Elon Musk's Birthday is 69 days after 4/20",
                "isComment": false
            }
        ],
        "like": [],
        "banner": "#3c96c3",
        "profilePicture": "DogeDesigner.png"
    },
    {
        "username": "LinusTech",
        "displayname": "Linus Tech Tips",
        "password": "123",
        "followers": [],
        "following": [],
        "bio": "The official Quacker of the Linus Tech Tips and Techquickie YouTube channels.",
        "quacks": [
            {
                "id": "LinusTech1",
                "likes": [],
                "comments": [],
                "quack": "is your boss really a boss if they dont eat lunch on the floor like a kindergartner",
                "isComment": false
            },
            {
                "id": "LinusTech2",
                "likes": [],
                "comments": [],
                "quack": "Trying to settle a debate here, which one is the better meme??? Linus selfie or sad linus",
                "isComment": false
            },
            {
                "id": "LinusTech3",
                "likes": [],
                "comments": [],
                "quack": "tech tip: the reason you're bad at the game is probably not your pc",
                "isComment": false
            }
        ],
        "like": [],
        "banner": "#e65828",
        "profilePicture": "LinusTech.png"
    }
]
if (!localStorage.userData) {
    localStorage.setItem("userData",JSON.stringify(startingUserData));
}